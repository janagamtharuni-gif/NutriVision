export interface FoodClassificationResult {
  foodName: string;
  confidence: number;
  category: 'Healthy' | 'Unhealthy' | 'Unknown';
  calories: string;
  benefits: string;
  icon: string;
}

export interface FoodItemInfo {
  id: string;
  name: string;
  category: 'Healthy' | 'Unhealthy';
  calories: string;
  benefits: string;
  icon: string;
  sampleImage: string;
}

export interface PythonFileMap {
  [filename: string]: string;
}
