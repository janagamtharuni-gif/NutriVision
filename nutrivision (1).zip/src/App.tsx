import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LiveWebClassifier } from './components/LiveWebClassifier';
import { PythonCodeExplorer } from './components/PythonCodeExplorer';
import { TeachableMachineGuide } from './components/TeachableMachineGuide';

export default function App() {
  const [activeTab, setActiveTab] = useState<'demo' | 'code' | 'guide'>('demo');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1">
        {activeTab === 'demo' && <LiveWebClassifier />}
        {activeTab === 'code' && <PythonCodeExplorer />}
        {activeTab === 'guide' && <TeachableMachineGuide />}
      </main>

      {/* App Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>🥗 Healthy Food Detection Using AI — Python, Tkinter, OpenCV & TensorFlow</p>
          <p>Offline Desktop Architecture + Google Teachable Machine Integration</p>
        </div>
      </footer>
    </div>
  );
}
