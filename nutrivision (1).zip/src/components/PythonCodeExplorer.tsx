import React, { useState, useEffect } from 'react';
import { FileCode2, Copy, Check, Download, FolderArchive, Terminal, ExternalLink } from 'lucide-react';
import { PythonFileMap } from '../types';

export const PythonCodeExplorer: React.FC = () => {
  const [files, setFiles] = useState<PythonFileMap>({});
  const [activeFile, setActiveFile] = useState<string>('main.py');
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch('/api/python-files')
      .then((res) => res.json())
      .then((data) => {
        if (data.files) {
          setFiles(data.files);
        }
      })
      .catch((err) => console.error('Failed to fetch Python files:', err))
      .finally(() => setLoading(false));
  }, []);

  const handleCopy = () => {
    const code = files[activeFile] || '';
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = (filename: string) => {
    const content = files[filename] || '';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    Object.keys(files).forEach((filename, idx) => {
      setTimeout(() => {
        handleDownloadSingle(filename);
      }, idx * 250);
    });
  };

  const currentCode = files[activeFile] || '';
  const lines = currentCode.split('\n');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-2">
            <Terminal className="w-3.5 h-3.5" />
            Complete Desktop Source Code
          </div>
          <h2 className="text-2xl font-extrabold text-white">
            Python & Tkinter Source Files
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Production-ready offline desktop application codebase. Download and run locally with Python 3.9+.
          </p>
        </div>

        <button
          onClick={handleDownloadAll}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm px-5 py-3 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-emerald-600/20 shrink-0"
        >
          <FolderArchive className="w-4 h-4" />
          Download All Files
        </button>
      </div>

      {/* Code Editor Frame */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {/* Tab Header */}
        <div className="bg-slate-950 border-b border-slate-800 px-4 pt-3 flex items-center justify-between overflow-x-auto">
          <div className="flex items-center space-x-1">
            {Object.keys(files).map((filename) => (
              <button
                key={filename}
                onClick={() => setActiveFile(filename)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-medium border-t border-x transition-all ${
                  activeFile === filename
                    ? 'bg-slate-900 border-slate-800 text-emerald-400 font-bold border-b-transparent'
                    : 'bg-slate-950/50 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <FileCode2 className="w-3.5 h-3.5" />
                {filename}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 pb-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied!' : 'Copy Code'}
            </button>

            <button
              onClick={() => handleDownloadSingle(activeFile)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 text-xs font-medium border border-emerald-500/30 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Download
            </button>
          </div>
        </div>

        {/* Code Content */}
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            Loading Python code files...
          </div>
        ) : (
          <div className="relative font-mono text-xs sm:text-sm bg-slate-950 p-4 overflow-x-auto max-h-[550px]">
            <div className="flex">
              {/* Line Numbers */}
              <div className="select-none text-right pr-4 text-slate-600 border-r border-slate-800/80 font-mono text-xs leading-6">
                {lines.map((_, idx) => (
                  <div key={idx}>{idx + 1}</div>
                ))}
              </div>

              {/* Code Text */}
              <pre className="pl-4 text-slate-200 font-mono leading-6 whitespace-pre">
                <code>{currentCode}</code>
              </pre>
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="bg-slate-950 border-t border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs text-slate-500">
          <span>{activeFile} • {lines.length} lines</span>
          <span>UTF-8 • Python 3.9+</span>
        </div>
      </div>
    </div>
  );
};
