import React, { useState, useRef, useEffect } from 'react';
import { Camera, CheckCircle2, AlertTriangle, RefreshCw, Upload, Sparkles, Activity, Flame, ShieldAlert, Heart, Info, ExternalLink } from 'lucide-react';
import { FoodClassificationResult } from '../types';

const SAMPLE_FOODS = [
  { name: 'Apple', icon: '🍎', category: 'Healthy', sampleImg: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80' },
  { name: 'Banana', icon: '🍌', category: 'Healthy', sampleImg: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80' },
  { name: 'Orange', icon: '🍊', category: 'Healthy', sampleImg: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80' },
  { name: 'Pizza', icon: '🍕', category: 'Unhealthy', sampleImg: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80' },
  { name: 'Burger', icon: '🍔', category: 'Unhealthy', sampleImg: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80' },
  { name: 'Chips', icon: '🍟', category: 'Unhealthy', sampleImg: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=600&q=80' },
];

export const LiveWebClassifier: React.FC = () => {
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<FoodClassificationResult | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<string>('Apple');
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Start webcam feed
  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.error('Camera access error:', err);
      let errorMsg = 'Unable to access camera. You can test using sample food images or file upload below.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.message?.includes('Permission denied')) {
        errorMsg = 'Camera permission was denied or restricted by the browser/iframe. Please grant camera permissions or open the app in a new tab.';
      }
      setCameraError(errorMsg);
      setIsCameraActive(false);
    }
  };

  // Stop webcam feed
  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Classify frame or image
  const handleDetect = async (imageSrc?: string, presetName?: string) => {
    setIsLoading(true);

    let base64Image = imageSrc || capturedImage;

    // If camera is running and no image provided, capture current webcam frame
    if (isCameraActive && videoRef.current && !imageSrc) {
      const video = videoRef.current;
      const canvas = canvasRef.current || document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        base64Image = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedImage(base64Image);
      }
      // Automatically end camera when image is captured
      stopCamera();
    }

    try {
      const response = await fetch('/api/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64Image,
          selectedFoodHint: presetName || selectedPreset
        })
      });

      if (!response.ok) {
        throw new Error('Classification request failed');
      }

      const data: FoodClassificationResult = await response.json();
      setResult(data);
    } catch (err) {
      console.error('Detection error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-detect default quick test sample on mount
  useEffect(() => {
    handleSelectPreset(SAMPLE_FOODS[0]);
  }, []);

  // Handle Preset Click
  const handleSelectPreset = (preset: typeof SAMPLE_FOODS[0]) => {
    setSelectedPreset(preset.name);
    setCapturedImage(preset.sampleImg);
    if (isCameraActive) {
      stopCamera();
    }
    handleDetect(preset.sampleImg, preset.name);
  };

  // Handle File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (isCameraActive) {
        stopCamera();
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setCapturedImage(base64);
        handleDetect(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Intro Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Interactive AI Food Classifier
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              NutriVision
            </h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Test real-time classification for Apple, Banana, Orange, Pizza, Burger, and Chips. Get instant calories, health tags, and 2-line nutritional analysis.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl border border-slate-700 cursor-pointer transition-all">
              <Upload className="w-4 h-4 text-emerald-400" />
              Upload Image
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>
        </div>
      </div>

      {/* Main Grid: Camera/Viewport Left, Nutrition Card Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT: CAMERA & MEDIA VIEWPORT */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Camera & Input Viewport</h3>
              </div>
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                isCameraActive ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                <span className={`w-2 h-2 rounded-full ${isCameraActive ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                {isCameraActive ? 'Webcam Live' : 'Camera Stopped'}
              </span>
            </div>

            {/* Error banner if webcam fails */}
            {cameraError && (
              <div className="mb-4 p-3.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">{cameraError}</p>
                    <p className="text-[11px] text-amber-400/80 mt-0.5">
                      Tip: If running inside an iframe, open in a new tab or click browser site settings to allow camera access.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => window.open(window.location.href, '_blank')}
                  className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 px-3 py-1.5 rounded-lg border border-amber-500/30 flex items-center gap-1.5 text-xs font-semibold shrink-0 transition-all self-start sm:self-auto"
                >
                  Open in New Tab
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Frame Viewport Container */}
            <div className="relative aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
              {/* Active Video Stream */}
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${isCameraActive ? 'block' : 'hidden'}`}
              />

              {/* Captured Image / Preset Image */}
              {!isCameraActive && capturedImage && (
                <img
                  src={capturedImage}
                  alt="Food Sample"
                  className="w-full h-full object-cover"
                />
              )}

              {/* Placeholder when offline & no image */}
              {!isCameraActive && !capturedImage && (
                <div className="text-center p-6 max-w-sm">
                  <div className="w-14 h-14 rounded-2xl bg-slate-800 border border-slate-700 text-slate-400 flex items-center justify-center mx-auto mb-3">
                    <Camera className="w-7 h-7" />
                  </div>
                  <p className="text-slate-300 font-medium text-sm">Webcam is currently inactive</p>
                  <p className="text-slate-500 text-xs mt-1">
                    Click 'Start Camera' or select a sample food item below to test classification.
                  </p>
                </div>
              )}

              {/* Hidden Canvas for Frame Capture */}
              <canvas ref={canvasRef} className="hidden" />

              {/* Overlay Loader */}
              {isLoading && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-20">
                  <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
                  <p className="text-emerald-300 font-semibold text-sm">Analyzing frame with Keras / Gemini AI...</p>
                </div>
              )}
            </div>
          </div>

          {/* Action Controls */}
          <div className="mt-5 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {!isCameraActive ? (
                <button
                  onClick={startCamera}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-emerald-600/20"
                >
                  <Camera className="w-4 h-4" />
                  Start Camera
                </button>
              ) : (
                <button
                  onClick={stopCamera}
                  className="bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-rose-600/20"
                >
                  Stop Camera
                </button>
              )}

              <button
                onClick={() => handleDetect()}
                disabled={isLoading || (!isCameraActive && !capturedImage)}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-blue-600/20"
              >
                <Sparkles className="w-4 h-4" />
                Detect Food
              </button>
            </div>

            <p className="text-xs text-slate-400">
              {isCameraActive ? 'Ready to capture frame' : 'Select a sample or start camera'}
            </p>
          </div>

          {/* Sample Food Presets Bar */}
          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
              Quick Test Samples
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {SAMPLE_FOODS.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleSelectPreset(item)}
                  className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                    selectedPreset === item.name && capturedImage === item.sampleImg
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-white shadow-md'
                      : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-300'
                  }`}
                >
                  <span className="text-xl">{item.icon}</span>
                  <span className="text-xs font-medium">{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT: NUTRITION ANALYSIS PANEL */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Nutritional Analysis</h3>
              </div>
              <span className="text-xs text-slate-400">Real-time Feedback</span>
            </div>

            {result ? (
              <div className="space-y-6">
                {/* Health Status Category Badge */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  result.category === 'Healthy'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                }`}>
                  <div className="flex items-center gap-3">
                    {result.category === 'Healthy' ? (
                      <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400">
                        <AlertTriangle className="w-6 h-6" />
                      </div>
                    )}
                    <div>
                      <span className="text-xs font-semibold uppercase tracking-wider block opacity-80">Health Classification</span>
                      <span className="text-lg font-bold">{result.category.toUpperCase()} CHOICE</span>
                    </div>
                  </div>
                  <span className={`text-2xl font-bold px-3 py-1 rounded-lg border ${
                    result.category === 'Healthy' ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                  }`}>
                    {result.category === 'Healthy' ? '✓' : '⚠'}
                  </span>
                </div>

                {/* Detected Food Name & Icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl p-2 rounded-2xl bg-slate-800 border border-slate-700">{result.icon || '🥗'}</span>
                    <div>
                      <h4 className="text-2xl font-extrabold text-white">{result.foodName}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">Predicted Class Label</p>
                    </div>
                  </div>
                </div>

                {/* Confidence Bar */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <div className="flex justify-between items-center text-xs font-medium text-slate-300 mb-1.5">
                    <span>Model Confidence Score</span>
                    <span className="text-emerald-400 font-bold">{result.confidence.toFixed(1)}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.max(10, result.confidence))}%` }}
                    />
                  </div>
                </div>

                {/* Calorie Card */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Flame className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Energy Density</span>
                    <span className="text-base font-bold text-slate-100">{result.calories}</span>
                  </div>
                </div>

                {/* Benefits & Health Notes (Minimum 2 Lines of Nutritional Analysis) */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-300 uppercase tracking-wider border-b border-slate-800/80 pb-2">
                    <div className="flex items-center gap-2">
                      <Info className="w-4 h-4 text-emerald-400" />
                      Nutritional Analysis (2 Lines)
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      Detailed Breakdown
                    </span>
                  </div>
                  <div className="space-y-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {result.benefits.split('\n').map((line, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/60">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 mt-1.5" />
                        <span className="font-medium text-slate-200">{line.replace(/^Line \d+:\s*/, '')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* Empty state */
              <div className="text-center py-12 px-4 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 text-slate-500 flex items-center justify-center mx-auto">
                  <Heart className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-slate-300 font-semibold text-base">Awaiting Food Classification</p>
                  <p className="text-slate-500 text-xs mt-1 max-w-xs mx-auto">
                    Start webcam and click 'Detect Food' or select a quick test sample from the left panel.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer Notice */}
          <div className="mt-6 pt-4 border-t border-slate-800 text-xs text-slate-500 flex items-center justify-between">
            <span>Powered by TensorFlow / Keras</span>
            <span>Local Database v1.0</span>
          </div>
        </div>
      </div>

      {/* Database Reference Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">Supported Food Classes Database</h3>
          </div>
          <span className="text-xs text-slate-400">6 Core Classes</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SAMPLE_FOODS.map((food) => (
            <div
              key={food.name}
              className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                food.category === 'Healthy'
                  ? 'bg-slate-950/60 border-emerald-500/20 hover:border-emerald-500/40'
                  : 'bg-slate-950/60 border-rose-500/20 hover:border-rose-500/40'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{food.icon}</span>
                  <div>
                    <h4 className="font-bold text-white text-base">{food.name}</h4>
                    <span className={`inline-block px-2 py-0.5 rounded text-xs font-semibold mt-0.5 ${
                      food.category === 'Healthy'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}>
                      {food.category}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
