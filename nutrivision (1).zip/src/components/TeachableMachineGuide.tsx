import React, { useState } from 'react';
import { ExternalLink, CheckCircle2, Circle, Download, Play, ShieldCheck, Sparkles, Cpu, FolderOpen } from 'lucide-react';

export const TeachableMachineGuide: React.FC = () => {
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});

  const toggleStep = (stepIdx: number) => {
    setCompletedSteps((prev) => ({ ...prev, [stepIdx]: !prev[stepIdx] }));
  };

  const steps = [
    {
      num: 1,
      title: "Open Google Teachable Machine",
      desc: "Navigate to Google's free online ML model trainer in your web browser.",
      actionUrl: "https://teachablemachine.withgoogle.com/train/image",
      actionText: "Open Teachable Machine",
      details: [
        "Select 'Image Project' from the home screen.",
        "Choose 'Standard Image Model' (224x224 input size)."
      ]
    },
    {
      num: 2,
      title: "Define the 6 Food Classes",
      desc: "Create 6 separate class categories matching the application database.",
      details: [
        "Class 1: Apple",
        "Class 2: Banana",
        "Class 3: Orange",
        "Class 4: Pizza",
        "Class 5: Burger",
        "Class 6: Chips"
      ]
    },
    {
      num: 3,
      title: "Record or Upload Dataset Images",
      desc: "Gather visual samples for each food class.",
      details: [
        "Click 'Webcam' to capture 50-100 real live frames holding up food items.",
        "Or click 'Upload' to select 30-50 sample images per food from disk.",
        "Ensure good lighting and varied angles for higher accuracy."
      ]
    },
    {
      num: 4,
      title: "Train Model in Browser",
      desc: "Train the deep neural network directly inside your web browser.",
      details: [
        "Click 'Train Model'.",
        "Keep default hyperparameters: Epochs = 50, Batch Size = 16, Learning Rate = 0.001.",
        "Wait 1-2 minutes until training completes."
      ]
    },
    {
      num: 5,
      title: "Export Keras (.h5) & labels.txt",
      desc: "Download model files formatted specifically for TensorFlow Python.",
      details: [
        "Click 'Export Model' in top right.",
        "Select the 'TensorFlow' tab (NOT TensorFlow.js).",
        "Select model type: 'Keras'.",
        "Click 'Download my model'.",
        "Extract downloaded zip to obtain 'keras_model.h5' and 'labels.txt'."
      ]
    },
    {
      num: 6,
      title: "Run Desktop Application",
      desc: "Place files in project root and execute Python main script.",
      details: [
        "Copy 'keras_model.h5' and 'labels.txt' into the root folder alongside main.py.",
        "Run: pip install -r requirements.txt",
        "Run: python main.py"
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-2">
              <Cpu className="w-3.5 h-3.5" />
              Zero-Code Machine Learning Training
            </div>
            <h2 className="text-2xl font-extrabold text-white">
              Google Teachable Machine Model Training Guide
            </h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Follow this step-by-step checklist to train and export your custom Keras model file (<code className="text-emerald-300">keras_model.h5</code>) for free in under 5 minutes.
            </p>
          </div>

          <a
            href="https://teachablemachine.withgoogle.com/train/image"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm px-5 py-3 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-emerald-600/20 shrink-0"
          >
            Open Teachable Machine
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Step by Step Checklist */}
      <div className="space-y-4">
        {steps.map((step, idx) => {
          const isDone = !!completedSteps[idx];
          return (
            <div
              key={step.num}
              onClick={() => toggleStep(idx)}
              className={`p-6 rounded-2xl border transition-all cursor-pointer ${
                isDone
                  ? 'bg-slate-900/90 border-emerald-500/40 shadow-lg'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <button className="mt-1 shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                    ) : (
                      <Circle className="w-6 h-6 text-slate-600 hover:text-slate-400" />
                    )}
                  </button>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        Step {step.num}
                      </span>
                      <h3 className={`text-lg font-bold ${isDone ? 'text-emerald-300 line-through opacity-80' : 'text-white'}`}>
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-slate-400 text-sm mt-1">{step.desc}</p>

                    {/* Step details bullet list */}
                    <ul className="mt-3 space-y-1.5 pl-2 border-l-2 border-slate-800 text-xs text-slate-300 font-mono">
                      {step.details.map((detail, dIdx) => (
                        <li key={dIdx} className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {step.actionUrl && (
                  <a
                    href={step.actionUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="shrink-0 bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold px-3.5 py-2 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-all"
                  >
                    {step.actionText}
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Instant Test Alternative Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-base font-bold text-white">Want to test python main.py immediately?</h4>
            <p className="text-slate-400 text-xs mt-0.5">
              Run <code className="text-amber-300 font-mono">python generate_dummy_model.py</code> in your project directory to auto-generate a valid test model and class labels file right now!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
